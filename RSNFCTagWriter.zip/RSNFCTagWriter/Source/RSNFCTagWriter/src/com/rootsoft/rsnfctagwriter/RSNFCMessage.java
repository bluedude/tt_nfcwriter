package com.rootsoft.rsnfctagwriter;

import android.nfc.FormatException;
import android.nfc.NdefMessage;
import android.nfc.NdefRecord;
import anywheresoftware.b4a.AbsObjectWrapper;
import anywheresoftware.b4a.BA.ShortName;

@ShortName("RSNFCMessage")
public class RSNFCMessage extends AbsObjectWrapper<NdefMessage>{
	
	//Attributes
	
	//Constructors - Initialization
	
	/**
	 * Represents an immutable NDEF Message.
	 * NDEF (NFC Data Exchange Format) is a light-weight binary format, used to encapsulate typed data. 
	 * It is specified by the NFC Forum, for transmission and storage with NFC, however it is transport agnostic.
	 * NDEF defines messages and records. An NDEF Record contains typed data, such as MIME-type media, a URI, or a custom application payload. 
	 * An NDEF Message is a container for one or more NDEF Records.
	 * When an Android device receives an NDEF Message (for example by reading an NFC tag) 
	 * it processes it through a dispatch mechanism to determine an activity to launch. The type of the first record in the message has 
	 * special importance for message dispatch, so design this record carefully.
	 */
	public void Initialize(NdefRecord record) throws FormatException {
		NdefRecord[] records = { record };
		NdefMessage message = new NdefMessage(records);
		
		setObject(message);
	}
	
	
	//Methods
	
	
	// GETTERS & SETTERS
	
	/**
	 * Return the length of this NDEF Message if it is written to a byte array with toByteArray().
	 * An NDEF Message can be formatted to bytes in different ways depending on chunking, SR, and ID flags, 
	 * so the length returned by this method may not be equal to the length of the original byte array used to construct this NDEF Message. 
	 * However it will always be equal to the length of the byte array produced by toByteArray().
	 * @return
	 */
	public int getByteArrayLength () {
		return getObject().getByteArrayLength();
	}
	
	/**
	 * Get the NDEF Records inside this NDEF Message.
	 */
	public NdefRecord[] getRecords () {
		return getObject().getRecords();
	}
	
	/**
	 * Return this NDEF Message as raw bytes.
	 * The NDEF Message is formatted as per the NDEF 1.0 specification, and the byte array is suitable for network transmission or storage in an NFC Forum NDEF compatible tag.
	 * This method will not chunk any records, and will always use the short record (SR) format and omit the identifier field when possible.
	 */
	public byte[] ByteArray () {
		return getObject().toByteArray();
	}
	
	//Events
	
	

}
