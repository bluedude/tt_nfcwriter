package com.rootsoft.rsnfctagwriter;

import java.io.IOException;

import android.nfc.FormatException;
import android.nfc.NdefMessage;
import android.nfc.Tag;
import android.nfc.tech.NdefFormatable;
import anywheresoftware.b4a.AbsObjectWrapper;
import anywheresoftware.b4a.BA.ShortName;

@ShortName("RSNFCNdefFormatable")
public class RSNFCNdefFormatable extends AbsObjectWrapper<NdefFormatable>{
	
	//Attributes

	//Constructors - Initialization
	
	/**
	 * Provide access to NDEF format operations on a Tag.
	 * Acquire a NdefFormatable object using get(Tag).
	 * Android devices with NFC must only enumerate and implement this class for tags for which it can format to NDEF.
	 */
	public void Initialize(Tag tag) throws FormatException {
		setObject(NdefFormatable.get(tag));
	}
	
	//Methods
	
	
	/**
	 * Disable I/O operations to the tag from this TagTechnology object, and release resources.
	 * Also causes all blocked I/O operations on other thread to be canceled and return with IOException.
	 * @throws IOException 
	 */
	public void Close() throws IOException {
		getObject().close();
	}
	
	/**
	 * Enable I/O operations to the tag from this TagTechnology object.
	 * May cause RF activity and may block. Must not be called from the main application thread. A blocked call will be canceled with IOException by calling close() from another thread.
	 * Only one TagTechnology object can be connected to a Tag at a time.
	 * Applications must call close() when I/O operations are complete.
	 * @throws IOException 
	 */
	public void Connect() throws IOException {
		getObject().connect();
	}
	
	/**
	 * Helper to indicate if I/O operations should be possible.
	 * Returns true if connect() has completed, and close() has not been called, and the Tag is not known to be out of range.
	 */
	public boolean isConnected () {
		return getObject().isConnected();
	}
	
	/**
	 * Format a tag as NDEF, and write a NdefMessage.
	 * This is a multi-step process, an IOException is thrown if any one step fails.
	 * The card is left in a read-write state after this operation.
	 */
	public void Format(NdefMessage firstMessage) throws IOException, FormatException {
		getObject().format(firstMessage);
	}
	
	
	
	
	
	//GETTERS & SETTERS
	
	
	/**
	 * Get the Tag object backing this TagTechnology object.
	 */
	public Tag getTag () {
		return getObject().getTag();
	}
	
	
	
	
	//Events
	
	


}
