package com.rootsoft.rsnfctagwriter;

import java.io.IOException;

import android.nfc.FormatException;
import android.nfc.NdefMessage;
import android.nfc.Tag;
import android.nfc.tech.Ndef;
import anywheresoftware.b4a.AbsObjectWrapper;
import anywheresoftware.b4a.BA.Permissions;
import anywheresoftware.b4a.BA.ShortName;

@ShortName("RSNFCNdef")
@Permissions(values = { "android.permission.NFC" })
public class RSNFCNdef extends AbsObjectWrapper<Ndef>{
	
	//Attributes

	//Constructors - Initialization
	public void Initialize(Tag tag) throws FormatException {
		setObject(Ndef.get(tag));
	}
	
	//Methods
	
	/**
	 * Indicates whether a tag can be made read-only with makeReadOnly().
	 * Does not cause any RF activity and does not block.
	 */
	public boolean CanMakeReadOnly() {
		return getObject().canMakeReadOnly();
	}
	
	/**
	 * Disable I/O operations to the tag from this TagTechnology object, and release resources.
	 * Also causes all blocked I/O operations on other thread to be canceled and return with IOException.
	 * @throws IOException 
	 */
	public void Close() throws IOException {
		getObject().close();
	}
	
	/**
	 * Enable I/O operations to the tag from this TagTechnology object.
	 * May cause RF activity and may block. Must not be called from the main application thread. A blocked call will be canceled with IOException by calling close() from another thread.
	 * Only one TagTechnology object can be connected to a Tag at a time.
	 * Applications must call close() when I/O operations are complete.
	 * @throws IOException 
	 */
	public void Connect() throws IOException {
		getObject().connect();
	}
	
	/**
	 * Helper to indicate if I/O operations should be possible.
	 * Returns true if connect() has completed, and close() has not been called, and the Tag is not known to be out of range.
	 */
	public boolean isConnected () {
		return getObject().isConnected();
	}
	
	/**
	 * Determine if the tag is writable.
	 * NFC Forum tags can be in read-only or read-write states.
	 * Does not cause any RF activity and does not block.
	 * @return
	 */
	public boolean isWritable () {
		return getObject().isWritable();
	}
	
	/**
	 * Make a tag read-only.
	 * This sets the CC field to indicate the tag is read-only, and where possible permanently sets the lock bits to prevent any further modification of the memory.
	 * This is a one-way process and cannot be reverted!
	 */
	public boolean MakeReadOnly () throws IOException {
		return getObject().makeReadOnly();
	}
	
	/**
	 * Get the NdefMessage that was read from the tag at discovery time.
	 * If the NDEF Message is modified by an I/O operation then it will not be updated here, 
	 * this function only returns what was discovered when the tag entered the field.
	 */
	public NdefMessage getCachedNdefMessage() {
		return getObject().getCachedNdefMessage();
	}
	
	/**
	 * Overwrite the NdefMessage on this tag.
	 * This is an I/O operation and will block until complete. 
	 * It must not be called from the main application thread.
	 * A blocked call will be canceled with IOException if close() is called from another thread.
	 */
	public void WriteNdefMessage (NdefMessage msg) throws IOException, FormatException {
		getObject().writeNdefMessage(msg);
	}
	
	//GETTERS & SETTERS
	
	/**
	 * Get the maximum NDEF message size in bytes.
	 */
	public int getMaxSize () {
		return getObject().getMaxSize();
	}
	
	/**
	 * Read the current NdefMessage on this tag.
	 * This always reads the current NDEF Message stored on the tag.
	 * Note that this method may return null if the tag was in the INITIALIZED state as defined by NFC Forum,
	 * as in that state the tag is formatted to support NDEF but does not contain a message yet.
	 */
	public NdefMessage getNdefMessage () throws IOException, FormatException {
		return getObject().getNdefMessage();
	}
	
	/**
	 * Get the Tag object backing this TagTechnology object.
	 */
	public Tag getTag () {
		return getObject().getTag();
	}
	
	/**
	 * Get the NDEF tag type.
	 * Returns one of NFC_FORUM_TYPE_1, NFC_FORUM_TYPE_2, NFC_FORUM_TYPE_3, NFC_FORUM_TYPE_4, MIFARE_CLASSIC 
	 * or another NDEF tag type that has not yet been formalized in this Android API.
	 */
	public String getType () {
		return getObject().getType();
	}
	
	
	//Events
	
	


}
