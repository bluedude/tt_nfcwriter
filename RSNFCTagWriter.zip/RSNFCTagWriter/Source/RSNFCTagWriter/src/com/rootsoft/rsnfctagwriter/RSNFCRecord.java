package com.rootsoft.rsnfctagwriter;

import android.nfc.NdefRecord;
import anywheresoftware.b4a.AbsObjectWrapper;
import anywheresoftware.b4a.BA.ShortName;

@ShortName("RSNFCRecord")
public class RSNFCRecord extends AbsObjectWrapper<NdefRecord>{
	
	//Attributes
	public static final short TNF_ABSOLUTE_URI = NdefRecord.TNF_ABSOLUTE_URI;
	public static final short TNF_EMPTY = NdefRecord.TNF_EMPTY;
	public static final short TNF_EXTERNAL_TYPE = NdefRecord.TNF_EXTERNAL_TYPE;
	public static final short TNF_MIME_MEDIA = NdefRecord.TNF_MIME_MEDIA;
	public static final short TNF_UNCHANGED = NdefRecord.TNF_UNCHANGED;
	public static final short TNF_UNKNOWN = NdefRecord.TNF_UNKNOWN;
	public static final short TNF_WELL_KNOWN = NdefRecord.TNF_WELL_KNOWN;
	
	public static final byte[] RTD_ALTERNATIVE_CARRIER = NdefRecord.RTD_ALTERNATIVE_CARRIER;
	public static final byte[] RTD_HANDOVER_CARRIER = NdefRecord.RTD_HANDOVER_CARRIER;
	public static final byte[] RTD_HANDOVER_REQUEST = NdefRecord.RTD_HANDOVER_REQUEST;
	public static final byte[] RTD_HANDOVER_SELECT = NdefRecord.RTD_HANDOVER_SELECT;
	public static final byte[] RTD_SMART_POSTER = NdefRecord.RTD_SMART_POSTER;
	public static final byte[] RTD_TEXT = NdefRecord.RTD_TEXT;
	public static final byte[] RTD_URI = NdefRecord.RTD_URI;
	
	//Constructors - Initialization
	
	/**
	 * Initializes this Ndef Record.
	 * NDEF (NFC Data Exchange Format) is a light-weight binary format, used to encapsulate typed data. 
	 * It is specified by the NFC Forum, for transmission and storage with NFC, however it is transport agnostic.
	 * 
	 * NDEF defines messages and records. 
	 * An NDEF Record contains typed data, such as MIME-type media, a URI, or a custom application payload. 
	 * An NDEF Message is a container for one or more NDEF Records.
	 */
	public void Initialize(short tnf, byte[] type, byte[] id, byte[] payload) {
		
		
		//Initialize the library
		NdefRecord recordNFC = new NdefRecord(tnf, type, id, payload);
		
		setObject(recordNFC);
	}
	
	
	//Methods
	
	
	// GETTERS & SETTERS
	
	/**
	 * Returns the variable length ID.
	 * Returns an empty byte array if this record does not have an id field.
	 */
	public byte[] getId() {
		return getObject().getId();
	}
	
	/**
	 * Returns the variable length payload.
	 * Returns an empty byte array if this record does not have a payload field.
	 */
	public byte[] getPayload() {
		return getObject().getPayload();
	}
	
	/**
	 * Returns the 3-bit TNF.
	 * TNF is the top-level type.
	 */
	public short getTnf()  {
		return getObject().getTnf();
	}
	
	/**
	 * Returns the variable length Type field.
	 * This should be used in conjunction with the TNF field to determine the payload format.
	 * Returns an empty byte array if this record does not have a type field.

	 */
	public byte[] getType() {
		return getObject().getType();
	}
	
	
	/**
	 * Map this record to a MIME type, or return null if it cannot be mapped.
	 * Currently this method considers all TNF_MIME_MEDIA records to be MIME records, as well as some TNF_WELL_KNOWN records such as RTD_TEXT. 
	 * If this is a MIME record then the MIME type as string is returned, otherwise null is returned.
	 * This method does not perform validation that the MIME type is actually valid. 
	 * It always attempts to return a string containing the type if this is a MIME record.
	 * The returned MIME type will by normalized to lower-case using normalizeMimeType(String).
	 * The MIME payload can be obtained using getPayload().
	 * @return
	 */
	public String ToMimeType () {
		return getObject().toMimeType();
	}
	
	//Events
	
	

}
