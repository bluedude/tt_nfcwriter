package com.rootsoft.rsnfctagwriter;

import android.nfc.Tag;
import anywheresoftware.b4a.AbsObjectWrapper;
import anywheresoftware.b4a.BA.ShortName;

@ShortName("RSNFCTag")
public class RSNFCTag extends AbsObjectWrapper<Tag>{
	
	//Attributes

	//Constructors - Initialization
	
	
	//Methods
	
	
	/**
	 * Descrobe the content of this tag.
	 * @return
	 */
	public int DescribeContents() {
		return getObject().describeContents();
	}
	
	public String ToString() {
		return getObject().toString();
	}
	
	
	
	//Getters & Setters
	
	/**
	 * Gets the id of this tag.
	 */
	public byte[] getId() {
		return getObject().getId();
	}
	
	/**
	 * Gets the tech list of this tag.
	 */
	public String[] getTechList() {
		return getObject().getTechList();
	}
	
	
	//Events
	
	


}
