package com.rootsoft.rsnfctagwriter;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.IntentFilter;
import android.nfc.NdefMessage;
import android.nfc.NfcAdapter;
import android.nfc.Tag;
import android.nfc.tech.Ndef;
import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.BA.ActivityObject;
import anywheresoftware.b4a.BA.Author;
import anywheresoftware.b4a.BA.ShortName;
import anywheresoftware.b4a.BA.Version;
import anywheresoftware.b4a.objects.IntentWrapper;


@ShortName("RSNFCTagWriter")
@Author("XverhelstX")
@Version(1.0f)
@ActivityObject
public class RSNFCTagWriter {
	
	//Attributes
	private BA ba; 
	private String eventName;
	private PendingIntent mNfcPendingIntent; 
	private NfcAdapter nfcAdapter;
	
	//Constructors - Initialization
	
	/**
	 * Initializes the RSNFCTagWriter.
	 */
	public void Initialize(final BA ba, String EventName) {
		this.ba = ba;
		this.eventName = EventName.toLowerCase(BA.cul);
		
	}
	
	private PendingIntent CreatePendingIntent(Activity Activity) {
		mNfcPendingIntent = PendingIntent.getActivity(BA.applicationContext, 0, new Intent(BA.applicationContext,  Activity.getClass()).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP), 0);
		return mNfcPendingIntent;
	}
	
	
	//Methods
	
	/**
	 * Gets the tag.
	 * First you should register an IntentFilter with the manifest editor.
	 * Returns null if no tag was found.
	 */
	public Tag getTag(IntentWrapper intent) {
		if(NfcAdapter.ACTION_TAG_DISCOVERED.equals(intent.getObject().getAction())){
	        Tag mytag = intent.getObject().getParcelableExtra(NfcAdapter.EXTRA_TAG);
	        return mytag;
	    } else {
	    	return null;
	    }
	}
	
	
	/**
	 *  Copies an array from the specified source array, beginning at the specified position, to the specified position of the destination array.
	 */
	public void ArrayCopy(Object src, int srcPos, Object dest, int destPos, int length) {
		System.arraycopy(src, srcPos, dest, destPos, length);
	}
	
	/**
	 * Writes the message to the given tag.
	 * @param tag The tag to write to
	 * @param message The message to be written
	 */
	public void Write(Tag tag, NdefMessage message) {
		Ndef ndef = Ndef.get(tag);
		
	    try {
			ndef.connect();
			ndef.writeNdefMessage(message);
			ndef.close();
			if (ba.subExists(eventName + "_success")==true) {
				ba.raiseEvent(this, eventName + "_success" );
			}
		} catch (Exception e) {
			if (ba.subExists(eventName + "_error")==true) {
				ba.raiseEvent(this, eventName + "_error", new Object[] { e.getMessage() } );
			}
		}
	}
	
	/**
	 * Enables the foreground dispatching of NFC to this activity.
	 */
	public void EnableForegroundDispatch() {
		nfcAdapter = NfcAdapter.getDefaultAdapter(BA.applicationContext);
		Activity activity = (Activity) ba.activity;
		PendingIntent pi = CreatePendingIntent(activity);
		IntentFilter tagDetected = new IntentFilter(NfcAdapter.ACTION_TAG_DISCOVERED);  	 
		nfcAdapter.enableForegroundDispatch(activity, pi, new IntentFilter[] {tagDetected}, null);
	}
	
	/**
	 * Disables the foreground dispatching.
	 */
	public void DisableForegroundDispatch() {
		nfcAdapter = NfcAdapter.getDefaultAdapter(BA.applicationContext);
		Activity activity = (Activity) ba.activity;
		nfcAdapter.disableForegroundDispatch(activity);
	}
	
	
	//Events
	
	


}
